module.exports = {
  future: {
    // removeDeprecatedGapUtilities: true,
    // purgeLayersByDefault: true,
  },
  purge: [],
  theme: {
    extend: {
      fontFamily: {
        'arial': 'Arial'
      },
      fontSize: {
        '12xl': '8rem'
      }
    },
  },
  variants: {},
  plugins: [],
}
